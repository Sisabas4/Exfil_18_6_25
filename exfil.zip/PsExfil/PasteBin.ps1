$api_dev_key = "Sr7XW66asb7g60gwsZoFSphbc6d27s5J"
$paste_code = "This is a test paste uploaded anonymously."
$params = @{
    api_dev_key           = $api_dev_key
    api_option            = "paste"
    api_paste_code        = $paste_code
    api_paste_private     = "1"        # unlisted
    api_paste_expire_date = "10M"      # 10 minutes
}

$response = Invoke-WebRequest -Uri "https://pastebin.com/api/api_post.php" -Method POST -Body $params
$response.Content
