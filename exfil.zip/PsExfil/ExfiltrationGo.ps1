param (
    [string]$Filename
)

# Function to display usage information
function Show-Usage {
    Write-Output "Usage: script.ps1 -Filename <filename>"
    exit 1
}

# Check if the filename parameter is provided
if (-not $Filename) {
    Show-Usage
}

# Check if the file exists
if (-not (Test-Path $Filename -PathType Leaf)) {
    Write-Output "File '$Filename' not found!"
    exit 1
}

# Create a multipart form request for PowerShell 5.x compatibility
$boundary = [System.Guid]::NewGuid().ToString()
$LF = "`r`n"
$fileBytes = [System.IO.File]::ReadAllBytes($Filename)
$fileContent = [System.Text.Encoding]::GetEncoding("ISO-8859-1").GetString($fileBytes)

$body = (
    "--$boundary",
    "Content-Disposition: form-data; name=`"file`"; filename=`"$([System.IO.Path]::GetFileName($Filename))`"",
    "Content-Type: application/octet-stream$LF",
    $fileContent,
    "--$boundary--$LF"
) -join $LF

$headers = @{
    "Content-Type" = "multipart/form-data; boundary=$boundary"
}

# Upload the file using Invoke-RestMethod
$response = Invoke-RestMethod -Uri "https://store10.gofile.io/contents/uploadfile" -Method Post -Headers $headers -Body $body

# Check if the response contains the downloadPage URL
$downloadPage = $response.data.downloadPage

if ($downloadPage) {
    Write-Output "File uploaded successfully!"
    Write-Output "Download page: $downloadPage"
} else {
    Write-Output "Failed to upload the file."
    Write-Output "Response: $($response | ConvertTo-Json -Depth 10)"
}
